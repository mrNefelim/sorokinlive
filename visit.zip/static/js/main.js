document.addEventListener('DOMContentLoaded', function(event) {
  document.getElementById('video').play();
});